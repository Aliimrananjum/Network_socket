from socket import *
import sys
import _thread as thread

def main():
    serverSocket = socket(AF_INET,SOCK_STREAM)
    serverPort = 20069
    serverSocket.bind(("",serverPort))
    serverSocket.listen(1)
    while True:
        print("Ready to server...")
        connectionSocket, addr = serverSocket.accept()
        thread.start_new_thread(handleClient, (connectionSocket,))
        print('Server connected by ', addr) 
        
    serverSocket.close()
    sys.exit()   

def handleClient(connection):
    try:
        message = connection.recv(1024).decode()
        filename = message.split()[1] 
        f = open(filename[1:])
        outputdata = f.read()
        f.close()
        responseHTTP = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: " + str(len(outputdata)) + "\r\n\r\n"
        connection.send(responseHTTP.encode())

        for i in range(0, len(outputdata)):
            connection.send(outputdata[i].encode())
        connection.send("\r\n\r\n".encode())
        connection.close()

    except IOError:
        htmlError="HTTP/1.1 400\r\n\r\n"
        connection.send(htmlError.encode())
        connection.close()

if __name__ == '__main__':
	main()
